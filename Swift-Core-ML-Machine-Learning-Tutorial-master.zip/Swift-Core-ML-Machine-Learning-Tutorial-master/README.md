Core ML Tutorial
==============================

Source code on the tuttorial on how to use Core ML and machine learning models in Swift.

Tutorial:

https://www.youtube.com/watch?v=h2MdQoRMtlQ&t

http://www.seemuapps.com/swift-coreml-image-recognition-tutorial

Check out our Website: http://www.seemuapps.com

Follow us on Twtitter: https://twitter.com/SeemuApps

Like us on Facebook: https://www.facebook.com/SeemuApps
